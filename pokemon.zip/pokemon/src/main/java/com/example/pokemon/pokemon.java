package com.example.pokemon;

import java.util.List;

public class pokemon {
    String imgSrc;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    String Name;
    String color;
    String description;
    String type;
    String height;
    String weight;
    String evolution;
    private String evolutionName;
    private String evolutionImage;

    public String getEvolutionName() {
        return evolutionName;
    }

    public void setEvolutionName(String evolutionName) {
        this.evolutionName = evolutionName;
    }
    String isFav;
    public String getEvolutionImage() {
        return evolutionImage;
    }

    public void setEvolutionImage(String evolutionImage) {
        this.evolutionImage = evolutionImage;
    }



    public int getID() {
        return ID;
    }


    public void setID(int ID) {
        this.ID = ID;
    }

    int ID;

    boolean isFavourite;

    public String getisFavourite() {
        return isFav;
    }

    public void setFavourite(String favourite) {
        isFav= favourite;
    }



    public String getImgSrc() {
        return imgSrc;
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getEvolution() {
        return evolution;
    }

    public void setEvolution(String evolution) {
        this.evolution = evolution;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String c) {
        color=c;
    }
}
