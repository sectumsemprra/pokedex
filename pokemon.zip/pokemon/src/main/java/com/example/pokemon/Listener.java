package com.example.pokemon;

public interface Listener {
    public void onClickListener(pokemon pkmn);

}
