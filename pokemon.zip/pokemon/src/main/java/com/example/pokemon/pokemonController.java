package com.example.pokemon;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class pokemonController implements Initializable {
    @FXML
    private  Button home;


    @FXML
    private VBox chosenPokemon;

    @FXML
    private ImageView ev1img;

    @FXML
    private ImageView ev2img;

    @FXML
    private ImageView ev3img;

    @FXML
    private Button fav;

    @FXML
    private ImageView favicon;
    @FXML
    private Label txt1;

    @FXML
    private Label txt2;

    @FXML
    private Label txt3;
    @FXML
    private Label weight;
    @FXML
    private Label height;


    @FXML
    private GridPane grid;

    @FXML
    private ImageView pokemonImage;

    @FXML
    private Label pokemonName;
    private pokemon chosenPoke;

    @FXML
    private ScrollPane scroll;
    private Image image;
    private Image image1;
    private List<pokemon> pokemonList = new ArrayList<>();
    private List<pokemon> FavList = new ArrayList<>();
    private Listener myListener;
    private boolean inFav = false;

    private List<pokemon> getData() {
        List<pokemon> temp = new ArrayList<>();
        pokemon pk;

        pk = new pokemon();
        pk.setColor("6A7324");
        pk.setName("Charmender");
        pk.setImgSrc("/image/004.png");
        temp.add(pk);
        pk = new pokemon();
        pk.setColor("#ff0000");
        pk.setName("Pikachu");
        pk.setImgSrc("/image/025.png");
        temp.add(pk);

        pk = new pokemon();
        pk.setColor("80080C");
        pk.setName("Charizard");
        pk.setImgSrc("/image/006.png");
        temp.add(pk);

        pk = new pokemon();
        pk.setColor("22371D");
        pk.setName("Dragonite");
        pk.setImgSrc("/image/dragonite.png");
        temp.add(pk);

        pk = new pokemon();
        pk.setColor("FB5D03");
        pk.setName("Jiggly puff");
        pk.setImgSrc("/image/jiggly_puff.png");
        temp.add(pk);


        pk = new pokemon();
        pk.setColor("291D36");
        pk.setName("ButterFree");
        pk.setImgSrc("/image/butterfree.png");
        temp.add(pk);

        pk = new pokemon();
        pk.setColor("E6E6FA");
        pk.setName("Pichu");
        pk.setImgSrc("/image/172.png");
        temp.add(pk);
        pk = new pokemon();
        pk.setColor("fff078");
        pk.setName("Raichu");
        pk.setImgSrc("/image/026.png");
        temp.add(pk);
        pk = new pokemon();
        pk.setColor("A7745B");
        pk.setName("Charmeleon");
        pk.setImgSrc("/image/005.png");
        temp.add(pk);
        pk = new pokemon();
        pk.setColor("FFB605");
        pk.setName("Zapdos");
        pk.setImgSrc("/image/10.png");
        temp.add(pk);
        /*pk = new pokemon();
        pk.setColor("#ff0000");
        pk.setName("Pikachu");
        pk.setImgSrc("/image/025.png");
        temp.add(pk); pk = new pokemon();
        pk.setColor("#ff0000");
        pk.setName("Pikachu");
        pk.setImgSrc("/image/025.png");
        temp.add(pk);*/
        return temp;
    }

    @FXML
    private Label type;

    private void setChosenPokemon(pokemon chosenPokemon1) {

        ev1img.setImage(null);
        ev2img.setImage(null);
        ev3img.setImage(null);
        txt1.setText("");
        txt2.setText("");
        txt3.setText("");
        pokemonImage.setImage(null);
        type.setText(chosenPokemon1.getType());
        System.out.println(chosenPokemon1.getID());
        weight.setText(chosenPokemon1.getWeight());
        height.setText(chosenPokemon1.getHeight());
        pokemonName.setText(chosenPokemon1.getName());
        if (chosenPokemon1.getisFavourite().equals("Y")) {
            image = new Image(getClass().getResourceAsStream("/image/icons8-heart-48.png"));
        }

        else
        {
            image = new Image(getClass().getResourceAsStream("/image/fav.png"));
        }
        favicon.setImage(image);
        image = new Image(getClass().getResourceAsStream(chosenPokemon1.getImgSrc()));

        String ev1 = chosenPokemon1.getEvolutionImage();
        String[] evolutionImages = ev1.split(";");

        for (int i = 0; i < evolutionImages.length; i++) {
            String imagePath = evolutionImages[i];
            image1 = new Image(getClass().getResourceAsStream(imagePath));
            if (i == 0) {
                ev1img.setImage(image1);
            } else if (i == 1) {
                ev2img.setImage(image1);
            } else if (i == 2) {
                ev3img.setImage(image1);
            }
        }

        String ev7 = chosenPokemon1.getEvolutionName();
        String[] evolutionNames = ev7.split(";");

        for (int i = 0; i < evolutionNames.length; i++) {
            String txtt = evolutionNames[i];
            if (i == 0) {
                txt1.setText(txtt);
            } else if (i == 1) {
                txt2.setText(txtt);
            } else if (i == 2) {
                txt3.setText(txtt);
            }
        }
        pokemonImage.setImage(image);
       chosenPokemon.setStyle("-fx-background-color: #" + chosenPokemon1.getColor() + ";\n" +
                "-fx-background-radius: 30;");
        /*chosenPokemon.setStyle(" background-color: #2c3e50; \n" +
                "    background-image: linear-gradient(45deg, #3498db, #e74c3c); \n" +
                "    border-radius: 10px; \n" +
                "    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3); \n" +
                "    color: #ffffff;");*/
        chosenPoke = chosenPokemon1;

    }

    public List<pokemon> getPokemonsFromDB() {
        List<pokemon> ls = new ArrayList<>();
        pokemon Pokemon = new pokemon();

        try {
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM POKEMON.POKEMON_TABLE2";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                Pokemon.setColor(resultSet.getString("color"));
                Pokemon.setName(resultSet.getString("name"));
                Pokemon.setType(resultSet.getString("type"));
                Pokemon.setDescription(resultSet.getString("description"));
                Pokemon.setHeight(resultSet.getString("height"));
                Pokemon.setWeight(resultSet.getString("weight"));
                Pokemon.setEvolutionName((resultSet.getString("evolution_name")));
                Pokemon.setEvolutionImage((resultSet.getString("evolution_image")));
                Pokemon.setImgSrc(resultSet.getString("img_src"));
                Pokemon.setFavourite(resultSet.getString("is_fav"));
                Pokemon.setID(resultSet.getInt("id"));
                ls.add(Pokemon);
                Pokemon = new pokemon();

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return ls;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        pokemonList.addAll(getPokemonsFromDB());
        home.setVisible(false);
        fav.setVisible(true);
        if (pokemonList.size() > 0) {
            setChosenPokemon(pokemonList.get(pokemonList.size() - 1));
            myListener = new Listener() {
                @Override
                public void onClickListener(pokemon pkmn) {
                    setChosenPokemon(pkmn);
                }
            };
        }
        int column = 0;
        int row = 1; // Start from row 1 to skip the header row, assuming there's one

        try {
            for (int i = 0; i <pokemonList.size(); i++) {
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_PREF_SIZE);

                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("pokemon.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();
                GridPane.setMargin(anchorPane, new Insets(10));
                // Use the pokeController instance directly to set the data
                pokeController poke = fxmlLoader.getController();
                poke.setData(pokemonList.get(i), myListener);
                if (column == 3) {
                    column = 0; // Reset column to 0
                    row++;      // Move to the next row
                }
                grid.add(anchorPane, column++, row); //(child,column,row)
                //set grid width


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public pokemon getPokemonsFromDBByName(String n) {
        pokemon Pokemon = new pokemon();

        try {
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);
            String query = "SELECT * FROM POKEMON.POKEMON_TABLE2 WHERE NAME = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, n); // Set the parameter value
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                Pokemon.setColor(resultSet.getString("color"));
                Pokemon.setName(resultSet.getString("name"));
                Pokemon.setType(resultSet.getString("type"));
                Pokemon.setDescription(resultSet.getString("description"));
                Pokemon.setHeight(resultSet.getString("height"));
                Pokemon.setWeight(resultSet.getString("weight"));
                Pokemon.setEvolutionName(resultSet.getString("evolution_name"));
                Pokemon.setEvolutionImage(resultSet.getString("evolution_image"));
                Pokemon.setImgSrc(resultSet.getString("img_src"));
                Pokemon.setFavourite(resultSet.getString("is_fav"));
            }

            connection.close(); // Don't forget to close the connection

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return Pokemon;
    }
    @FXML
    private  TextField search;
    @FXML
    public void search_click(ActionEvent e)
    {
        String n = search.getText();
        pokemon pkmn = new pokemon();
        pkmn = getPokemonsFromDBByName(n);
        setChosenPokemon(pkmn);
    }
    private Listener listener2;


    public List<pokemon> favPokemon;


    @FXML
    private void favClick(MouseEvent mouseEvent) {

       // favicon.setDisable(true);
            System.out.println(chosenPoke.getisFavourite());
            if (chosenPoke.getisFavourite().equals("N")) {
                add_to_fav(chosenPoke);
                chosenPoke.setFavourite("Y");
                image = new Image(getClass().getResourceAsStream("/image/icons8-heart-48.png"));
                favicon.setImage(image);

        }
        else if (chosenPoke.getisFavourite().equals("Y")) {
            remove_from_fav(chosenPoke);
                chosenPoke.setFavourite("N");
            image = new Image(getClass().getResourceAsStream("/image/fav.png"));
            favicon.setImage(image);
        }
       // favicon.setDisable(false);

    }
    public void add_to_fav(pokemon pkmn) {
        int i = pkmn.getID();
        try {
            System.out.println(i);
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);

            // Insert into POKEMON_FAV table
            String insertQuery = "INSERT INTO POKEMON.FAV (ID) VALUES (?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
            insertStatement.setInt(1, i);
            insertStatement.executeUpdate();

            // Update IS_FAV in POKEMON_TABLE2
            String updateQuery = "UPDATE POKEMON.POKEMON_TABLE2 SET IS_FAV = ? WHERE id = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, "Y");
            updateStatement.setInt(2, i);
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Value updated successfully!");
            } else {
                System.out.println("No rows updated.");
            }

            // Close the connection
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void remove_from_fav(pokemon pkmn) {
        int i = pkmn.getID();
        try {
            System.out.println(i);
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);

            // Insert into POKEMON_FAV tableString
             String deleteQuery = "DELETE FROM POKEMON.FAV WHERE ID = ?";
            PreparedStatement insertStatement = connection.prepareStatement(deleteQuery);
            insertStatement.setInt(1, i);
            insertStatement.executeUpdate();

            // Update IS_FAV in POKEMON_TABLE2
            String updateQuery = "UPDATE POKEMON.POKEMON_TABLE2 SET IS_FAV = ? WHERE id = ?";
            PreparedStatement updateStatement = connection.prepareStatement(updateQuery);
            updateStatement.setString(1, "N");
            updateStatement.setInt(2, i);
            int rowsUpdated = updateStatement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Value updated successfully!");
            } else {
                System.out.println("No rows updated.");
            }

            // Close the connection
            connection.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    @FXML
    public void show_home(ActionEvent e2)

    {
        favicon.setVisible(true);
        fav.setVisible(true);
        home.setVisible(false);
        grid.getChildren().clear();
        pokemonList.clear();
        pokemonList.addAll(getPokemonsFromDB());
        if (pokemonList.size() > 0) {
            setChosenPokemon(pokemonList.get(1));
            myListener = new Listener() {
                @Override
                public void onClickListener(pokemon pkmn) {
                    setChosenPokemon(pkmn);
                }
            };
        }
        int column = 0;
        int row = 1; // Start from row 1 to skip the header row, assuming there's one

        try {
            for (int i = 0; i <pokemonList.size(); i++) {
                grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                grid.setMaxWidth(Region.USE_PREF_SIZE);

                //set grid height
                grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                grid.setMaxHeight(Region.USE_PREF_SIZE);

                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("pokemon.fxml"));
                AnchorPane anchorPane = fxmlLoader.load();
                GridPane.setMargin(anchorPane, new Insets(10));
                // Use the pokeController instance directly to set the data
                pokeController poke = fxmlLoader.getController();
                poke.setData(pokemonList.get(i), myListener);
                if (column == 3) {
                    column = 0; // Reset column to 0
                    row++;      // Move to the next row
                }
                grid.add(anchorPane, column++, row); //(child,column,row)
                //set grid width


            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void show_favourite(ActionEvent e1)
    {

            favicon.setVisible(false);
            fav.setVisible(false);
            home.setVisible(true);
           // inFav = true;
            grid.getChildren().clear();
            //System.out.println("F clicked");
             FavList.clear();
            FavList.addAll(getPokemonsFromFav());

            if (FavList.size() > 0) {
                System.out.println("lal");
                //setChosenPokemon(pokemonList.get(pokemonList.size() - 1));
                myListener = new Listener() {
                    @Override
                    public void onClickListener(pokemon pkmn) {
                        setChosenPokemon(pkmn);
                    }
                };
            }
            int column = 0;
            int row = 1; // Start from row 1 to skip the header row, assuming there's one

            try {
                for (int i = 0; i < FavList.size(); i++) {
                    grid.setMinWidth(Region.USE_COMPUTED_SIZE);
                    grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
                    grid.setMaxWidth(Region.USE_PREF_SIZE);

                    //set grid height
                    grid.setMinHeight(Region.USE_COMPUTED_SIZE);
                    grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
                    grid.setMaxHeight(Region.USE_PREF_SIZE);

                    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("pokemon.fxml"));
                    AnchorPane anchorPane = fxmlLoader.load();
                    GridPane.setMargin(anchorPane, new Insets(10));
                    // Use the pokeController instance directly to set the data
                    pokeController poke = fxmlLoader.getController();
                    poke.setData(FavList.get(i), myListener);
                    if (column == 3) {
                        column = 0; // Reset column to 0
                        row++;      // Move to the next row
                    }
                    grid.add(anchorPane, column++, row); //(child,column,row)
                    //set grid width


                }

            } catch (IOException e) {
                e.printStackTrace();
            }

    }
    public List<pokemon> getPokemonsFromFav() {
        List<pokemon> ls = new ArrayList<>();
        int[] arr = new int[11];
        int index = 0;
        try {
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();


            String favQuery = "SELECT * FROM POKEMON.FAV";
            ResultSet favResultSet = statement.executeQuery(favQuery);
            while (favResultSet.next() && index < 11) {
                arr[index] = favResultSet.getInt("ID");
                index++;
            }

            // Retrieve pokemon details based on IDs
            String pokemonQuery = "SELECT * FROM POKEMON.POKEMON_TABLE2 WHERE ID = ?";
            for (int i = 0; i < index; i++) {
                int id = arr[i];
                PreparedStatement preparedStatement = connection.prepareStatement(pokemonQuery);
                preparedStatement.setInt(1, id);
                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    pokemon Pokemon = new pokemon(); // Create a new pokemon object
                    Pokemon.setColor(resultSet.getString("color"));
                    Pokemon.setName(resultSet.getString("name"));
                    Pokemon.setType(resultSet.getString("type"));
                    Pokemon.setDescription(resultSet.getString("description"));
                    Pokemon.setHeight(resultSet.getString("height"));
                    Pokemon.setWeight(resultSet.getString("weight"));
                    Pokemon.setEvolutionName(resultSet.getString("evolution_name"));
                    Pokemon.setEvolutionImage(resultSet.getString("evolution_image"));
                    Pokemon.setImgSrc(resultSet.getString("img_src"));
                    Pokemon.setFavourite(resultSet.getString("is_fav"));
                    ls.add(Pokemon);
                }

                resultSet.close();
                preparedStatement.close();
            }

            // Close resources
            favResultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
       //  System.out.println(ls.size());
        return ls;
    }

}

