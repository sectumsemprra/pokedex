package com.example.pokemon;

import java.sql.*;

public class jdbc {
    public static void main(String[] args) {
        try {
            String url = "jdbc:mysql://127.0.0.1:3306/pokemon";
            String user = "root";
            String password = "rakhi180303";
            Connection connection = DriverManager.getConnection(url, user, password);
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM POKEMON.POKEMON_TABLE2";
            ResultSet resultSet = statement.executeQuery(query);
            pokemon Pokemon = new pokemon();
            while (resultSet.next()) {
                   Pokemon.setColor(resultSet.getString("color"));
                   Pokemon.setName(resultSet.getString("name"));
                   Pokemon.setType(resultSet.getString("type"));
                   Pokemon.setDescription(resultSet.getString("description"));
                    Pokemon.setHeight(resultSet.getString("height"));
                    Pokemon.setWeight(resultSet.getString("weight"));
                    Pokemon.setEvolutionName((resultSet.getString("evolution_name")));
                    Pokemon.setEvolutionImage((resultSet.getString("evolution_image")));
                    Pokemon.setImgSrc(resultSet.getString("img_src"));
                    Pokemon.setFavourite(resultSet.getString("is_fav"));
                //ls.add(pokemon);
                //Pokemon = new pokemon();

                //System.out.println(resultSet.getString("description"));


            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
}


