package com.example.pokemon;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.input.MouseEvent;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class pokeController {
    @FXML
    private ImageView pokeimg;

    @FXML
    private Label pokelabel;
    @FXML
    private AnchorPane anchor;
    private pokemon poke;
    private  Listener listener1;
    @FXML
    private void click(MouseEvent mouseEvent)
    {
        System.out.println("AnchorPane clicked!");
        listener1.onClickListener(poke);
    }
    public void setData(pokemon pk, Listener listener)
    {
        listener1=listener;
        poke = pk;
        pokelabel.setText(poke.getName());
        try {
            InputStream inputStream = getClass().getResourceAsStream(poke.getImgSrc());
            if (inputStream != null) {
                Image image = new Image(inputStream);
                pokeimg.setImage(image);
                // Use the image as needed
            } else {
                // Handle case where input stream is null (image not found)
                System.out.println("Image file not found!");
            }
        } catch (NullPointerException e) {
            // Handle NullPointerException
            e.printStackTrace();
        }


    }

}

